mysqldump --complete-insert --no-create-info -u root -p shows > shows.sql
